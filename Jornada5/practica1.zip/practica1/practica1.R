
##---- Practica 1 ----##

# Install and load packages
# install.packages('biogeo')
# install.packages('sp')
library(sp)
library(biogeo)

rm(list = ls(all.names = TRUE))
# set your working directory here
setwd("")

#### Coordinates transformation 

# A. From UTM 22S to decimal degree WGS84 -------------------------------------

# 1. Load your data
utm_p <- read.csv("utm22_original.csv", header=TRUE, sep=";")

# 2. Transform dataframe into spatialPoints
coordinates(utm_p) <- c("UTM1", "UTM2")

# 3. assign the current projection
proj4string(utm_p) <- CRS("+init=epsg:32722") #see epsg.io to find the code

# 4. transform points with the new projection
wgs <- spTransform(utm_p, CRS("+init=epsg:4326")) # Code for WGS84 is 4326

# 5. transform your new SpatialPoints into dataframe
wgs <- as.data.frame(wgs) 

# 6. Save the data
write.table(wgs,"utmToDec.csv", sep=";", row.names = FALSE)


# B. DMS to decimal degree WGS84 ------------------------------------------

# 1. Load your data
dms <- read.csv("DMS_CoordsSubset.csv", header=TRUE, sep=";")
View(dms)

# 2. Assign degree / minute / second  to separate vectors and transform

# For latitude
dd <- dms$ddLat
mm <- dms$mmLat
ss <- dms$ssLat
ns <- dms$nsLat

newLat <- dms2dd(dd,mm,ss,ns) # dms transformation into dd

dms <- cbind(dms, newLat) # bind the result to our dataset

# For longitude
dd <- dms$ddLon
mm <- dms$mmLon
ss <- dms$ssLon
ns <- dms$nsLon

newLon <- dms2dd(dd,mm,ss,ns) # dms transformation into dd

dms <- cbind(dms, newLon) # bind the result to our dataset

# Let's see what we've done
View(dms)

# Let's simplify our output
dms <- dms[ ,c('id', 'newLat', 'newLon')]
# And save it
write.table(dms,"outputDegTransformation.csv", sep=";", row.names = FALSE) 

