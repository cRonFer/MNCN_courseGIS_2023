# Practica 2: Detectar centroides y duplicados

# Load packages ---------------------------------------------------------
library(tidyverse)  # data manipulation

library(CoordinateCleaner)  # data cleaning functions
library(biogeo) #data duplicates

# Environment and data ----------------------------------------------------
rm(list = ls(all.names = TRUE))
setwd("")

# Read occurrences csv and check dimensions
data <- read.csv("alimoche_gadm.csv", sep=";", header= TRUE) 

# Centroids check --------------------------------------------------------

# Are coordinates placed in a country's centroids? (10km buffer)
cap <- cc_cap (
  data,
  lon = "decimalLon",
  lat = "decimalLat",
  value = "flagged")
data <- cbind(data, cap)

# Are coordinates from locality or province centroids? (1km buffer)
cen <- cc_cen(
  data,
  lon = "decimalLon",
  lat = "decimalLat",
  value = "flagged")
data <- cbind(data, cen)

# Are coordinates placed in gbif headquarters?
gbif <- cc_gbif(
  data,
  lon = "decimalLon",
  lat = "decimalLat",
  value = "flagged")
data <- cbind(data, gbif)

# Are coordinates from museums, gardens, institutions, zoo's... ?
inst <- cc_inst(
  data,
  lon = "decimalLon",
  lat = "decimalLat",
  value = "flagged")
data <- cbind(data, inst)

# Save dataset
write.table(data, 'centroids_Analysis.csv', sep=";", row.names = FALSE)

# Filter and exclude centroids
data_correct <- data %>% 
                filter(cap =='TRUE' &
                       inst =='TRUE' &
                       gbif =='TRUE' &
                       cen =='TRUE'
                      )

# Filter and exclude 'sea' records
data_correct <- data_correct %>% 
                  filter(NAME_0 != "")

# DUPLICATE CHECK ---------------------------------------------------------

# Let's make some combination of fields to detect duplicate records?

### Lat Lon + Year + recordedBy
dataDuplic1b <- cc_dupl (data_correct,
                         lon = "decimalLon",
                         lat = "decimalLat",
                         additions = c('recordedBy', 'year'))
### Lat Lon + recordedBy
dataDuplic2b <- cc_dupl (data_correct,
                         lon = "decimalLon",
                         lat = "decimalLat",
                         additions = 'recordedBy')
### Lat Lon + Year
dataDuplic3b <- cc_dupl (data_correct,
                         lon = "decimalLon",
                         lat = "decimalLat",
                         additions = 'year')
### Lat Lon
dataDuplic4b <- cc_dupl (data_correct,
                         lon = "decimalLon",
                         lat = "decimalLat")
### Lat Lon with rounded coordinates
data_correct$lon_round <- round(data_correct$decimalLon, 2)
data_correct$lat_round <- round(data_correct$decimalLat, 2)

dataDuplic5b <- cc_dupl (data_correct,
                         lon = "lon_round",
                         lat = "lat_round")
### SpeciesName + cell
datbiogeo <- keepmainfields(data_correct, 
                              ID='gbifID',Species='species', 
                              x='decimalLon', y='decimalLat')

dataDuplic6b <- duplicatesexclude(datbiogeo, 10) # spatial resolution in minutes

dataDuplic6b <- dataDuplic6b %>% 
                  filter(Exclude == 0)
